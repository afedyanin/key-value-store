﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Reflection;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;

namespace TreeCodeAnalysisApp
{
    internal class Program
    {
        private static PropertyInfo _greenProperty;
        private static FieldInfo _tokenNodeField;
        private static FieldInfo _triviaNodeField;
        private static bool _fieldsResolved;

        static void Main()
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;

            string code = "class Test {\r\n  void M1(){}\r\n  // :D \r\n  void M2(){}\r\n}";
            var tree = CSharpSyntaxTree.ParseText(code);
            var root = tree.GetRoot();

            // Разрешаем рефлексию один раз
            ResolveInternals(root);

            Console.WriteLine("=== ЭТАП 1: Исходное дерево ===");
            PrintTree(root, null);

            // Меняем M1 на RenamedM1
            var m1Token = root.DescendantTokens().First(t => t.Text == "M1");
            var newRoot = root.ReplaceToken(m1Token, SyntaxFactory.Identifier("RenamedM1"));

            // Собираем хэш-сет "Зелёных" узлов (Green Nodes) старого дерева
            var oldGreenNodes = new HashSet<object>(ReferenceEqualityComparer.Instance);
            CollectGreenNodes(root, oldGreenNodes);

            Console.WriteLine();
            Console.WriteLine("=== ЭТАП 2: Обновлённое дерево ===");
            PrintTree(newRoot, oldGreenNodes);

            Console.WriteLine();
            Console.WriteLine("ЛЕГЕНДА:");
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.Write("■ Node (Shared) ");
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.Write("■ Node (New) ");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write("■ Token ");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("■ Trivia");
            Console.ResetColor();
        }

        /// <summary>
        /// Один раз находим нужные поля/свойства через рефлексию.
        /// Перебираем возможные имена полей для разных версий Roslyn.
        /// </summary>
        static void ResolveInternals(SyntaxNode anyNode)
        {
            if (_fieldsResolved) return;
            _fieldsResolved = true;

            // SyntaxNode.Green — internal property
            _greenProperty = typeof(SyntaxNode).GetProperty("Green",
                BindingFlags.NonPublic | BindingFlags.Instance);

            // SyntaxToken — ищем internal-поле, хранящее green node
            // В разных версиях Roslyn оно может называться "_node", "Node", "_token" и т.д.
            _tokenNodeField = FindField(typeof(SyntaxToken), "_node", "node", "Node");

            // SyntaxTrivia — аналогично
            _triviaNodeField = FindField(typeof(SyntaxTrivia), "_node", "node", "Node");

            // Диагностика: если не нашли — выведем все поля, чтобы понять структуру
            if (_tokenNodeField == null)
            {
                Console.WriteLine("[DEBUG] SyntaxToken fields:");
                foreach (var f in typeof(SyntaxToken).GetFields(BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Public))
                    Console.WriteLine("  " + f.FieldType.Name + " " + f.Name);
            }
            if (_triviaNodeField == null)
            {
                Console.WriteLine("[DEBUG] SyntaxTrivia fields:");
                foreach (var f in typeof(SyntaxTrivia).GetFields(BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Public))
                    Console.WriteLine("  " + f.FieldType.Name + " " + f.Name);
            }
        }

        static FieldInfo FindField(Type type, params string[] candidates)
        {
            var flags = BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Public;
            foreach (var name in candidates)
            {
                var fi = type.GetField(name, flags);
                if (fi != null) return fi;
            }
            // Если не нашли по имени — ищем первое поле, тип которого из пространства Roslyn internal (GreenNode)
            foreach (var fi in type.GetFields(flags))
            {
                if (fi.FieldType.Name == "GreenNode"
                    || fi.FieldType.Name == "SyntaxToken"
                    || fi.FieldType.Name == "SyntaxTrivia"
                    || fi.FieldType.FullName != null && fi.FieldType.FullName.Contains("InternalSyntax"))
                    return fi;
            }
            return null;
        }

        static void CollectGreenNodes(SyntaxNode root, HashSet<object> set)
        {
            foreach (var n in root.DescendantNodesAndTokensAndSelf())
            {
                var g = GetGreenFromNodeOrToken(n);
                if (g != null) set.Add(g);

                if (n.IsToken)
                {
                    var token = n.AsToken();
                    foreach (var tr in token.LeadingTrivia)
                    {
                        var gt = GetGreenFromTrivia(tr);
                        if (gt != null) set.Add(gt);
                    }
                    foreach (var tr in token.TrailingTrivia)
                    {
                        var gt = GetGreenFromTrivia(tr);
                        if (gt != null) set.Add(gt);
                    }
                }
            }
        }

        static object GetGreenFromNode(SyntaxNode node)
        {
            if (node == null || _greenProperty == null) return null;
            return _greenProperty.GetValue(node);
        }

        static object GetGreenFromToken(SyntaxToken token)
        {
            if (_tokenNodeField == null) return null;
            // Для структуры нужно боксировать и передать боксированную копию
            object boxed = token;
            return _tokenNodeField.GetValue(boxed);
        }

        static object GetGreenFromTrivia(SyntaxTrivia trivia)
        {
            if (_triviaNodeField == null) return null;
            object boxed = trivia;
            return _triviaNodeField.GetValue(boxed);
        }

        static object GetGreenFromNodeOrToken(SyntaxNodeOrToken item)
        {
            if (item.IsNode)
                return GetGreenFromNode(item.AsNode());
            else
                return GetGreenFromToken(item.AsToken());
        }

        static void PrintTree(SyntaxNode node, HashSet<object> oldRefs, string indent = "")
        {
            PrintNode(node, indent, oldRefs);

            foreach (var child in node.ChildNodesAndTokens())
            {
                if (child.IsNode)
                {
                    PrintTree(child.AsNode(), oldRefs, indent + "  ");
                }
                else
                {
                    var token = child.AsToken();

                    // Leading trivia
                    var leading = token.LeadingTrivia;
                    for (int i = 0; i < leading.Count; i++)
                    {
                        PrintTrivia(leading[i], indent + "    ", oldRefs);
                    }

                    // Token
                    PrintToken(token, indent + "  ", oldRefs);

                    // Trailing trivia
                    var trailing = token.TrailingTrivia;
                    for (int i = 0; i < trailing.Count; i++)
                    {
                        PrintTrivia(trailing[i], indent + "    ", oldRefs);
                    }
                }
            }
        }

        static void PrintNode(SyntaxNode node, string indent, HashSet<object> oldRefs)
        {
            object green = GetGreenFromNode(node);
            if (green == null) return;

            bool isNew = oldRefs != null && !oldRefs.Contains(green);
            string addr = string.Format("[G:{0:X8}]", RuntimeHelpers.GetHashCode(green));

            Console.ForegroundColor = isNew ? ConsoleColor.Magenta : ConsoleColor.Blue;
            Console.WriteLine(string.Format("{0}{1} Node: {2}", indent, addr, node.Kind()));
            Console.ResetColor();
        }

        static void PrintToken(SyntaxToken token, string indent, HashSet<object> oldRefs)
        {
            object green = GetGreenFromToken(token);
            if (green == null) return;

            bool isNew = oldRefs != null && !oldRefs.Contains(green);
            string addr = string.Format("[G:{0:X8}]", RuntimeHelpers.GetHashCode(green));

            Console.ForegroundColor = isNew ? ConsoleColor.Magenta : ConsoleColor.Green;
            string label = isNew ? "Token (New)" : "Token";
            Console.WriteLine(string.Format("{0}{1} {2}: '{3}'", indent, addr, label, token.Text));
            Console.ResetColor();
        }

        static void PrintTrivia(SyntaxTrivia trivia, string indent, HashSet<object> oldRefs)
        {
            object green = GetGreenFromTrivia(trivia);
            if (green == null) return;

            bool isNew = oldRefs != null && !oldRefs.Contains(green);
            string addr = string.Format("[G:{0:X8}]", RuntimeHelpers.GetHashCode(green));

            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(string.Format("{0}{1} Trivia: {2}", indent, addr, trivia.Kind()));
            Console.ResetColor();
        }
    }

    /// <summary>
    /// Сравнение по ссылке (ReferenceEquals) для HashSet.
    /// </summary>
    internal sealed class ReferenceEqualityComparer : IEqualityComparer<object>
    {
        public static readonly ReferenceEqualityComparer Instance = new ReferenceEqualityComparer();

        private ReferenceEqualityComparer() { }

        bool IEqualityComparer<object>.Equals(object x, object y)
        {
            return ReferenceEquals(x, y);
        }

        int IEqualityComparer<object>.GetHashCode(object obj)
        {
            return RuntimeHelpers.GetHashCode(obj);
        }
    }
}