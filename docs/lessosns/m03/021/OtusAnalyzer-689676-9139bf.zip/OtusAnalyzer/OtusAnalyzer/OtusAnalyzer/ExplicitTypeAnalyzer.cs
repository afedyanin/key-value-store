﻿using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using Microsoft.CodeAnalysis.Diagnostics;
using OtusAnalyzer;
using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Threading;

namespace CSharpAnalyzers
{
    [DiagnosticAnalyzer(LanguageNames.CSharp)]
    public class ExplicitTypeAnalyzer : DiagnosticAnalyzer
    {
        public const string DiagnosticId = "OA3";

        private static readonly LocalizableString Title = new LocalizableResourceString(nameof(Resources.OA3Title), Resources.ResourceManager, typeof(Resources));
        private static readonly LocalizableString MessageFormat = new LocalizableResourceString(nameof(Resources.OA3MessageFormat), Resources.ResourceManager, typeof(Resources));
        private static readonly LocalizableString Description = new LocalizableResourceString(nameof(Resources.OA3Description), Resources.ResourceManager, typeof(Resources));
        private const string Category = "Samples";

        private static DiagnosticDescriptor Rule = new DiagnosticDescriptor(DiagnosticId, Title, MessageFormat, Category, DiagnosticSeverity.Warning, isEnabledByDefault: true, description: Description);

        public override ImmutableArray<DiagnosticDescriptor> SupportedDiagnostics { get { return ImmutableArray.Create(Rule); } }

        public override void Initialize(AnalysisContext context)
        {
            context.RegisterSyntaxNodeAction(syntaxNodeContext =>
            {
                // Find implicitly typed variable declarations.
                // Do not flag implicitly typed declarations that declare more than one variables,
                // as the compiler already generates error CS0819 for those cases.
                var declaration = (VariableDeclarationSyntax)syntaxNodeContext.Node;
                if (!declaration.Type.IsVar || declaration.Variables.Count != 1)
                {
                    return;
                }

                // Do not flag variable declarations with error type or special System types, such as int, char, string, etc.
                var typeInfo = syntaxNodeContext.SemanticModel.GetTypeInfo(declaration.Type, syntaxNodeContext.CancellationToken);
                if (typeInfo.Type.TypeKind == TypeKind.Error || typeInfo.Type.SpecialType != SpecialType.None)
                {
                    return;
                }

                // Report a diagnostic.
                var variable = declaration.Variables[0];
                var diagnostic = Diagnostic.Create(Rule, variable.GetLocation(), variable.Identifier.ValueText);
                syntaxNodeContext.ReportDiagnostic(diagnostic);
            }, SyntaxKind.VariableDeclaration);
        }
    }
}
