﻿using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using Microsoft.CodeAnalysis.Diagnostics;
using OtusAnalyzer;
using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Threading;

namespace CSharpAnalyzers
{
    [DiagnosticAnalyzer(LanguageNames.CSharp)]
    public class UnusedParametersAnalyzer : DiagnosticAnalyzer
    {
        public const string DiagnosticId = "OA5";

        private static readonly LocalizableString Title = new LocalizableResourceString(nameof(Resources.OA5Title), Resources.ResourceManager, typeof(Resources));
        private static readonly LocalizableString MessageFormat = new LocalizableResourceString(nameof(Resources.OA5MessageFormat), Resources.ResourceManager, typeof(Resources));
        private static readonly LocalizableString Description = new LocalizableResourceString(nameof(Resources.OA5Description), Resources.ResourceManager, typeof(Resources));
        private const string Category = "Samples";

        private static DiagnosticDescriptor Rule = new DiagnosticDescriptor(DiagnosticId, Title, MessageFormat, Category, DiagnosticSeverity.Warning, isEnabledByDefault: true, description: Description);

        public override ImmutableArray<DiagnosticDescriptor> SupportedDiagnostics { get { return ImmutableArray.Create(Rule); } }

        public override void Initialize(AnalysisContext context)
        {
            context.RegisterCodeBlockStartAction<SyntaxKind>(startCodeBlockContext =>
            {
                // We only care about method bodies.
                if (startCodeBlockContext.OwningSymbol.Kind != SymbolKind.Method)
                {
                    return;
                }

                // We only care about methods with parameters.
                var method = (IMethodSymbol)startCodeBlockContext.OwningSymbol;
                if (method.Parameters.IsEmpty)
                {
                    return;
                }

                // Initialize local mutable state in the start action.
                var analyzer = new UnusedParametersSearcher(method);

                // Register an intermediate non-end action that accesses and modifies the state.
                startCodeBlockContext.RegisterSyntaxNodeAction(analyzer.AnalyzeSyntaxNode,
                 SyntaxKind.IdentifierName);

                // Register an end action to report diagnostics based on the final state.
                startCodeBlockContext.RegisterCodeBlockEndAction(analyzer.CodeBlockEndAction);
            });
        }

        private class UnusedParametersSearcher
        {
            #region Per-CodeBlock mutable state
            private readonly HashSet<IParameterSymbol> _unusedParameters;
            private readonly HashSet<string> _unusedParameterNames;
            #endregion

            #region State intialization
            public UnusedParametersSearcher(IMethodSymbol method)
            {
                // Initialization: Assume all parameters are unused, except for:
                //  1. Implicitly declared parameters
                //  2. Parameters with no locations (example auto-generated parameters for accessors)
                var parameters = method.Parameters.Where(p => !p.IsImplicitlyDeclared && p.Locations.Length > 0);
                _unusedParameters = new HashSet<IParameterSymbol>(parameters);
                _unusedParameterNames = new HashSet<string>(parameters.Select(p => p.Name));
            }
            #endregion

            #region Intermediate actions
            public void AnalyzeSyntaxNode(SyntaxNodeAnalysisContext context)
            {
                // Check if we have any pending unreferenced parameters.
                if (_unusedParameters.Count == 0)
                {
                    return;
                }

                // Syntactic check to avoid invoking GetSymbolInfo for every identifier.
                var identifier = (IdentifierNameSyntax)context.Node;
                if (!_unusedParameterNames.Contains(identifier.Identifier.ValueText))
                {
                    return;
                }

                // Mark parameter as used.
                var parmeter = context.SemanticModel.GetSymbolInfo(identifier, context.CancellationToken).Symbol as IParameterSymbol;
                if (parmeter != null && _unusedParameters.Contains(parmeter))
                {
                    _unusedParameters.Remove(parmeter);
                    _unusedParameterNames.Remove(parmeter.Name);
                }
            }
            #endregion

            #region End action
            public void CodeBlockEndAction(CodeBlockAnalysisContext context)
            {
                // Report diagnostics for unused parameters.
                foreach (var parameter in _unusedParameters)
                {
                    var diagnostic = Diagnostic.Create(Rule, parameter.Locations[0], parameter.Name, parameter.ContainingSymbol.Name);
                    context.ReportDiagnostic(diagnostic);
                }
            }
            #endregion

        }
    }
}
