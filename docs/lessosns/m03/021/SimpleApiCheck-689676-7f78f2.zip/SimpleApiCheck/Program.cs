﻿using Microsoft.Build.Locator;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeAnalysisApp1
{
    internal class Program
    {
        static async Task Main(string[] args)
        {
            // Устанавливаем кодировку UTF-8 для корректного вывода кириллицы
            Console.OutputEncoding = Encoding.UTF8;

            // Код, который мы будем анализировать
            string code = @"
                using System;
                class Demo {
                    static void Main() {
                        int count = 5;
                        Console.WriteLine(count);
                    }
                }";

            // --- 1. SYNTAX TREE API (Синтаксис) ---
            // Мы превращаем текст в дерево узлов. Это просто структура: скобки, имена, точки с запятой.
            SyntaxTree tree = CSharpSyntaxTree.ParseText(code);
            CompilationUnitSyntax root = tree.GetCompilationUnitRoot();

            // Находим узел объявления переменной "count"
            VariableDeclaratorSyntax variableNode = root.DescendantNodes()
                .OfType<VariableDeclaratorSyntax>().First();

            Console.WriteLine("[1. Syntax API]: Найден узел переменной в тексте: " + variableNode.Identifier.Text);

            // --- 2. SYMBOL API (Символы / Метаданные) ---
            // Это "картотека" всех типов и методов. Здесь мы работаем с определениями из библиотек.
            CSharpCompilation compilation = CSharpCompilation.Create("MyAssembly")
                .AddReferences(MetadataReference.CreateFromFile(typeof(object).Assembly.Location))
                .AddSyntaxTrees(tree);

            // Получаем символ системного типа 'int' (System.Int32) напрямую из метаданных .NET
            INamedTypeSymbol intSymbol = compilation.GetSpecialType(SpecialType.System_Int32);

            Console.WriteLine("[2. Symbol API]: Инфо из метаданных: Тип 'int' находится в сборке: " + intSymbol.ContainingAssembly.Name);

            // --- 3. BINDING API (Связывание / Семантика) ---
            // Это мост между Синтаксисом (текстом) и Символами (смыслом). 
            // Отвечает на вопрос: "К какому именно символу относится этот кусок текста?"
            SemanticModel semanticModel = compilation.GetSemanticModel(tree);

            // Связываем конкретный узел из кода (variableNode) с его семантическим описанием (Symbol)
            ILocalSymbol localSymbol = (ILocalSymbol)semanticModel.GetDeclaredSymbol(variableNode);

            Console.WriteLine("[3. Binding API]: Узел '" + variableNode.Identifier.Text +
                              "' успешно связан с символом: " + localSymbol.Name +
                              ", который имеет тип: " + localSymbol.Type);

            // --- 4. EMIT API (Генерация кода) ---
            // Финальный этап: превращаем всё вышеперечисленное в реальные байты исполняемого файла.
            using (MemoryStream ms = new MemoryStream())
            {
                var result = compilation.Emit(ms);
                Console.WriteLine("[4. Emit API]: Успех компиляции? " + result.Success);

                if (result.Success)
                {
                    Console.WriteLine("Сборка успешно создана. Размер: " + ms.Length + " байт.");
                }
            }

            Console.WriteLine("\nГотово. Нажми любую клавишу для выхода...");            
        }

    }
}
