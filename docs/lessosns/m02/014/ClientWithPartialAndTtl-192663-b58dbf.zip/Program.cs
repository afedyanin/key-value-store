﻿using System.Net.Sockets;
using System.Text;

class Program
{
    private const string ServerHost = "127.0.0.1";
    private const int ServerPort = 7777;

    static async Task Main(string[] args)
    {
        Console.WriteLine("Клиент для занятия «Практикум: Пишем асинхронный TCP-сервер для кэша»");
        Console.WriteLine("===========================");
        Console.WriteLine();

        while (true)
        {
            Console.WriteLine("Выберите действие:");
            Console.WriteLine("1. Отправить команду (с симуляцией частичной отправки)");
            Console.WriteLine("2. Отправить команду с TTL (с симуляцией частичной отправки)");
            Console.WriteLine("3. Ручной ввод команд (отправка целиком)");
            Console.WriteLine("4. Выход");
            Console.Write("> ");

            var choice = Console.ReadKey().KeyChar;
            Console.WriteLine();

            switch (choice)
            {
                case '1':
                    await SendPredefinedCommand(withTtl: false);
                    break;
                case '2':
                    await SendPredefinedCommand(withTtl: true);
                    break;
                case '3':
                    await ManualCommandLoop();
                    break;
                case '4':
                    return;
                default:
                    Console.WriteLine("Неверный выбор. Попробуйте еще раз.");
                    break;
            }
        }
    }

    private static async Task SendPredefinedCommand(bool withTtl)
    {
        try
        {
            using var client = new InteractiveCacheClient();
            await client.ConnectAsync(ServerHost, ServerPort);

            Console.WriteLine("\n--- Симуляция частичной отправки ---");

            // Готовим команду
            string key = $"user:{Random.Shared.Next(1000, 9999)}";
            string value = $"data_for_{key}_{Guid.NewGuid()}";
            var valueLength = Encoding.UTF8.GetByteCount(value);
            string command = withTtl
                ? $"SET {key} {valueLength} {value} 15\r\n" // TTL 15 секунд
                : $"SET {key} {valueLength} {value}\r\n";

            // Отправляем по частям
            await client.SendPartiallyAsync(command);

            // Читаем ответ
            var response = await client.ReadResponseAsync();
            Console.WriteLine($"[СЕРВЕР]: {response}");

            // Отправляем вторую команду, чтобы проверить, что соединение живое
            await client.SendAsync($"GET {key}\r\n");
            response = await client.ReadResponseAsync();
            Console.WriteLine($"[СЕРВЕР]: {response}");

        }
        catch (Exception ex)
        {
            Console.WriteLine($"ОШИБКА: {ex.Message}");
        }
    }

    private static async Task ManualCommandLoop()
    {
        try
        {
            using var client = new InteractiveCacheClient();
            await client.ConnectAsync(ServerHost, ServerPort);
            Console.WriteLine("\n--- Ручной ввод команд (введите 'exit' для выхода) ---");

            while (true)
            {
                Console.Write("Введите команду (например, GET mykey): ");
                string command = Console.ReadLine();

                if (string.IsNullOrWhiteSpace(command) || command.Equals("exit", StringComparison.OrdinalIgnoreCase))
                {
                    break;
                }

                // В ручном режиме команды должны заканчиваться на \r\n, но для удобства добавим если нет
                if (!command.EndsWith("\r\n"))
                {
                    command += "\r\n";
                }

                await client.SendAsync(command);
                var response = await client.ReadResponseAsync();
                Console.WriteLine($"[СЕРВЕР]: {response}");
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"ОШИБКА: {ex.Message}");
        }
    }
}

/// <summary>
/// Простой клиент, управляющий одним TCP-соединением.
/// </summary>
class InteractiveCacheClient : IDisposable
{
    private TcpClient _tcpClient;
    private NetworkStream _stream;
    private StreamReader _reader;
    private StreamWriter _writer;

    public async Task ConnectAsync(string host, int port)
    {
        _tcpClient = new TcpClient();
        await _tcpClient.ConnectAsync(host, port);
        _stream = _tcpClient.GetStream();

        // Устанавливаем NoDelay для интерактивности, как в задании
        _tcpClient.NoDelay = true;

        // Используем StreamReader/Writer для удобной работы с текстовым протоколом
        // Важно: не закрывать базовый поток (leaveOpen: true)
        var encoding = Encoding.UTF8;
        _reader = new StreamReader(_stream, encoding, leaveOpen: true);
        _writer = new StreamWriter(_stream, encoding, leaveOpen: true) { AutoFlush = true };

        Console.WriteLine($"Подключено к {host}:{port}");
    }

    /// <summary>
    /// Отправляет данные одной командой.
    /// </summary>
    public async Task SendAsync(string message)
    {
        if (_writer == null) throw new InvalidOperationException("Клиент не подключен");
        Console.WriteLine($"[КЛИЕНТ->]: {message.TrimEnd()}");
        await _writer.WriteAsync(message);
    }

    /// <summary>
    /// Симулирует отправку данных по частям.
    /// </summary>
    public async Task SendPartiallyAsync(string message)
    {
        if (_stream == null) throw new InvalidOperationException("Клиент не подключен");

        Console.WriteLine($"[КЛИЕНТ->]: Отправка по частям -> {message.TrimEnd()}");

        var data = Encoding.UTF8.GetBytes(message);

        // Разделяем сообщение на 2-3 части для демонстрации
        int part1Length = data.Length / 3;
        int part2Length = data.Length / 3;
        int part3Length = data.Length - part1Length - part2Length;

        // Часть 1
        await _stream.WriteAsync(data, 0, part1Length);
        Console.WriteLine($"  ...отправлена часть 1 ({part1Length} байт)");
        await Task.Delay(50); // Небольшая задержка, чтобы сервер успел прочитать

        // Часть 2
        await _stream.WriteAsync(data, part1Length, part2Length);
        Console.WriteLine($"  ...отправлена часть 2 ({part2Length} байт)");
        await Task.Delay(50);

        // Часть 3 (остаток)
        await _stream.WriteAsync(data, part1Length + part2Length, part3Length);
        Console.WriteLine($"  ...отправлена часть 3 ({part3Length} байт)");

        await _stream.FlushAsync();
    }


    /// <summary>
    /// Читает одну строку ответа от сервера.
    /// </summary>
    public async Task<string> ReadResponseAsync()
    {
        if (_reader == null) throw new InvalidOperationException("Клиент не подключен");

        string response = await _reader.ReadLineAsync(); // ReadLineAsync ищет \n или \r\n
        return response ?? "[Соединение закрыто]";
    }

    public void Dispose()
    {
        _reader?.Dispose();
        _writer?.Dispose();
        _stream?.Dispose();
        _tcpClient?.Dispose();
    }
}