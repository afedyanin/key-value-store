﻿using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Running;

[MemoryDiagnoser]
public class SumBench
{
	private int[] data = Enumerable.Range(1, 1000).ToArray();

	[Benchmark]
	public int ForLoop()
	{
		int s = 0;
		for (int i = 0; i < data.Length; i++) s += data[i];
		return s; // возвращаем, чтобы код не выкинули
	}
}

public class Program
{
	public static void Main() => BenchmarkRunner.Run<SumBench>();
}