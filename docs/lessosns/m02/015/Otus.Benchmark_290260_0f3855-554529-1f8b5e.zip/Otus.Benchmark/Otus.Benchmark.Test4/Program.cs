﻿using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Columns;
using BenchmarkDotNet.Configs;
using BenchmarkDotNet.Engines;
using BenchmarkDotNet.Environments;
using BenchmarkDotNet.Jobs;
using BenchmarkDotNet.Order;
using BenchmarkDotNet.Running;
using System.Runtime.CompilerServices;

[MemoryDiagnoser, RankColumn, Orderer(SummaryOrderPolicy.FastestToSlowest)]
public class AntiPatternsDemo
{
	private readonly Consumer _consumer = new();

	[Params(1_000, 100_000)] public int N;
	private int[] _data = null!;

	[GlobalSetup]
	public void Setup() => _data = Enumerable.Range(1, N).ToArray();

	//результат не используется — оптимизатор может выбросить работу
	[Benchmark(Baseline = true)]
	public void Bad_Sum()
	{
		int s = 0;
		for (int i = 0; i < _data.Length; i++) s += _data[i];
		// ничего не возвращаем и не потребляем
	}

	// потребляем результат, чтобы запретить выброс
	[Benchmark]
	public void Good_Sum_Consume()
	{
		int s = 0;
		for (int i = 0; i < _data.Length; i++) s += _data[i];
		_consumer.Consume(s); // или return s;
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	private static int Add(int a, int b) => a + b;

	[Benchmark]
	[InvocationCount(128)]
	public void Good_WithInvocation()
	{
		int s = 0;
		for (int i = 0; i < _data.Length; i++) s = Add(s, _data[i]);
		_consumer.Consume(s);
	}
}

public class Program
{
	public static void Main()
	{
		var cfg = DefaultConfig.Instance
			.AddJob(Job.Default
				.WithRuntime(CoreRuntime.Core80)
				.WithPlatform(Platform.X64)
				.WithId(".NET 8 x64"))
			.WithOption(ConfigOptions.DisableOptimizationsValidator, true);
		BenchmarkRunner.Run<AntiPatternsDemo>(cfg);
	}
}
