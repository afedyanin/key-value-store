﻿using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Columns;
using BenchmarkDotNet.Configs;
using BenchmarkDotNet.Environments;
using BenchmarkDotNet.Jobs;
using BenchmarkDotNet.Order;
using BenchmarkDotNet.Running;


[Config(typeof(MyConfig))]
[MemoryDiagnoser, RankColumn, Orderer(SummaryOrderPolicy.FastestToSlowest)]
public class SumBench
{
	private int[] data = Enumerable.Range(1, 1000).ToArray();

	[Benchmark]
	public int ForLoop()
	{
		int s = 0;
		for (int i = 0; i < data.Length; i++) s += data[i];
		return s; // возвращаем, чтобы код не выкинули
	}
}

public class MyConfig : ManualConfig
{
	public MyConfig()
	{
		AddColumn(RankColumn.Stars, StatisticColumn.Median, StatisticColumn.StdDev, StatisticColumn.Min, StatisticColumn.Max);

		// .NET 8, x64, Server GC
		var net8 = Job.Default
			.WithId(".NET 8 / ServerGC")
			.WithRuntime(CoreRuntime.Core80)
			.WithPlatform(Platform.X64)
			.WithJit(Jit.RyuJit)
			.WithGcServer(true);

		// .NET 9, x64, Workstation GC
		var net9 = Job.Default
			.WithId(".NET 9 / WorkstationGC")
			.WithRuntime(CoreRuntime.Core90)
			.WithPlatform(Platform.X64)
			.WithJit(Jit.RyuJit)
			.WithGcServer(false);

		AddJob(net8);
		AddJob(net9);

	}
}

public class Program
{
	public static void Main() => BenchmarkRunner.Run<SumBench>();
}