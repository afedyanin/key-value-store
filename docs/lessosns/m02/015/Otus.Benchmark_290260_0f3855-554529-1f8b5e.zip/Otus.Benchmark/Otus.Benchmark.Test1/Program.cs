﻿//// CPU-bound
using System.Diagnostics;

static long CpuWork(int n = 40) // наивный Фибоначчи
	=> n <= 1 ? n : CpuWork(n - 1) + CpuWork(n - 2);

// I/O-bound (эмуляция ожидания)
static async Task IoWorkAsync()
{
	using var client = new HttpClient();
	await Task.Delay(200);
}

var sw = Stopwatch.StartNew();
var cpu = CpuWork(); // нагружаем CPU
sw.Stop();
Console.WriteLine($"CPU-bound: {sw.ElapsedMilliseconds} ms");

sw.Restart();
await IoWorkAsync(); // нагружаем ожиданием
sw.Stop();
Console.WriteLine($"I/O-bound: {sw.ElapsedMilliseconds} ms");
