﻿using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Columns;
using BenchmarkDotNet.Order;
using BenchmarkDotNet.Running;

[MemoryDiagnoser, RankColumn, Orderer(SummaryOrderPolicy.FastestToSlowest)]
public class LookupBench
{
	[Params(1_000, 10_000, 100_000)]
	public int N;

	[Params("hit", "miss", "mixed")]
	public string Mode = null!;

	private int[] _data = null!;
	private HashSet<int> _set = null!;
	private int[] _probes = null!;

	[GlobalSetup]
	public void Setup()
	{
		_data = Enumerable.Range(0, N).ToArray();
		_set = _data.ToHashSet();

		_probes = Mode switch
		{
			"hit" => new[] { 0, N / 2, N - 1, 42 },
			"miss" => new[] { -1, -2, -3, -4 },
			_ => new[] { 0, -1, N - 1, N + 1 } // mixed
		};
	}

	[Benchmark(Baseline = true)]
	public int ListContains()
	{
		int hits = 0;
		foreach (var x in _probes) if (((IList<int>)_data).Contains(x)) hits++;
		return hits;
	}

	[Benchmark]
	public int SetContains()
	{
		int hits = 0;
		foreach (var x in _probes) if (_set.Contains(x)) hits++;
		return hits;
	}
}


public class Program
{
	public static void Main() => BenchmarkRunner.Run<LookupBench>();
}