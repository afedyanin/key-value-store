﻿using System;
using System.Diagnostics;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace TraceStandaloneDemo;

public static class Program
{
	private static readonly Regex ErrorRx =
		new("error", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);

	private static readonly string[] Lines = GenerateLines(20_000);
	private static readonly Random Rnd = new(123);

	public static async Task Main(string[] args)
	{
		if (args.Length == 0 || args[0] is "-h" or "--help")
		{
			PrintUsage();
			return;
		}

		string mode = args[0].ToLowerInvariant();
		int seconds = (args.Length > 1 && int.TryParse(args[1], out var s) && s > 0) ? s : 60;

		Console.WriteLine($"Mode={mode}, Duration={seconds}s, PID={Environment.ProcessId}");
		Console.WriteLine("Tip: attach with 'dotnet-trace ps' → 'dotnet-trace collect -p <PID> ...'");
		Console.WriteLine();

		var sw = Stopwatch.StartNew();
		long loops = 0, hits = 0;

		while (sw.Elapsed < TimeSpan.FromSeconds(seconds))
		{
			// 1) CPU-нагрузка (поиск подстроки)
			if (mode is "cpu-slow" or "cpu-fast" or "mix")
			{
				for (int i = 0; i < 3000; i++)
				{
					var sline = Lines[Rnd.Next(Lines.Length)];
					bool ok = mode is "cpu-slow"
						? SlowMatch(sline)              // медленнее
						: FastMatch(sline);             // быстрее
					if (ok) hits++;
				}
			}

			// Генерация мусора
			if (mode is "gc-alloc" or "mix")
			{
				for (int k = 0; k < 300; k++)
				{
					var tmp = new byte[200_000];
					tmp[0] = (byte)k;
					tmp[tmp.Length - 1] = (byte)(k ^ 0x5A);
				}
			}

			loops++;

			// Небольшая пауза, чтобы было удобно подключаться инструментами
			await Task.Delay(5);

			if (loops % 50 == 0)
				Console.WriteLine($"[{sw.Elapsed:mm\\:ss}] loops={loops}, hits={hits}");
		}

		Console.WriteLine($"Done. loops={loops}, hits={hits}");
	}

	// Медленный путь: лишняя работа со строками + Regex.IsMatch
	private static bool SlowMatch(string s)
	{
		// toLowerInvariant создаёт новую строку, значит больше работы GC/CPU
		var lower = s.ToLowerInvariant();
		return ErrorRx.IsMatch(lower);
	}

	// Быстрый путь: без лишних строк, простой поиск без регулярок
	private static bool FastMatch(string s) =>
		s.IndexOf("error", StringComparison.OrdinalIgnoreCase) >= 0;

	private static string[] GenerateLines(int n)
	{
		var arr = new string[n];
		for (int i = 0; i < n; i++)
		{
			string sev = (i % 7 == 0) ? "ERROR" : (i % 5 == 0) ? "WARN" : "INFO";
			arr[i] = $"{i},2025-10-20T10:{i % 60:D2}:00Z,{sev},UserId={(i * 37) % 1000},Msg=hello-{i}";
		}
		return arr;
	}

	private static void PrintUsage()
	{
		Console.WriteLine("Usage:");
		Console.WriteLine("  dotnet run -c Release -- cpu-slow [seconds]   # тяжёлый поиск подстроки (CPU)");
		Console.WriteLine("  dotnet run -c Release -- cpu-fast [seconds]   # быстрый поиск подстроки (CPU)");
		Console.WriteLine("  dotnet run -c Release -- gc-alloc [seconds]   # генерация мусора (GC)");
		Console.WriteLine("  dotnet run -c Release -- mix [seconds]        # CPU + мусор одновременно");
		Console.WriteLine();
		Console.WriteLine("Tips:");
		Console.WriteLine("  1) Use Release/x64. 2) Attach with dotnet-trace. 3) Record 30–60s under typical load.");
	}
}
